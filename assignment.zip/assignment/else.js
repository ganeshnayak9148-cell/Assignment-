let driverAge = 14;
if (driverAge >= 18) {
  console.log("You can drive.");
} else {
  console.log("You are too young to drive.");
}

let a = 10;
let b = 20;
if (a > b) {
  console.log("A is larger than B");
} else {
  console.log("B is larger than A");
}

let val = -5;
if (val > 0) {
  console.log("Positive number");
} else {
  console.log("Negative number");
}

let num = 15;
if (num % 2 === 0) {
  console.log("The number is even.");
} else {
  console.log("The number is odd.");
}

let score = 35;
if (score >= 40) {
  console.log("Result: Pass");
} else {
  console.log("Result: Fail");
}

let age = 20;
if (age >= 18) {
  console.log("You are old enough to vote.");
} else {
  console.log("You are too young to vote.");
}

let temperature = 32; 
if (temperature > 28) {
  console.log("It is a hot day! Stay hydrated.");
} else {
  console.log("The weather is pleasant.");
}
