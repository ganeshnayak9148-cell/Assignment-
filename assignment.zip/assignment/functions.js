function add(a, b) {
  return a + b;
}
console.log(add(3, 4));

function greet(name) {
  console.log("Hello " + name);
}
greet("Uzair");

function square(num) {
  return num * num;
}
console.log(square(5));

function isEven(n) {
  if (n % 2 === 0) {
    return true;
  }
  return false;
}
console.log(isEven(10));

function multiply(x, y) {
  return x * y;
}
console.log(multiply(6, 7));