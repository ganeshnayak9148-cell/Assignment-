let age = 21;
if (age >= 18) {
  console.log("Access granted.");
}

let total = 150;
if (total > 100) {
  console.log("You qualify for a 10% discount!");
}

let score = 500;
let highScore = 450;
if (score > highScore) {
  console.log("New High Score Achieved!");
}

let stockCount = 3;
if (stockCount < 5) {
  console.log("Stock is low. Please restock soon!");
}

let batteryLevel = 15;
if (batteryLevel < 20) {
  console.log("Low battery! Please plug in your charger.");
}

let cartTotal = 60;
if (cartTotal >= 50) {
  console.log("Your order is eligible for free shipping.");
}

let tempCelsius = -2;
if (tempCelsius <= 0) {
  console.log("Caution: Road conditions may be icy.");
}

