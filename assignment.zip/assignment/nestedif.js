let n = 4;

if (n > 0) {
  if (n % 2 === 0) {
    console.log("Positive and even");
  }
}

let age = 20;

if (age >= 18) {
  if (age <= 60) {
    console.log("Eligible");
  }
}

let user = "admin";
let pass = "1234";

if (user === "admin") {
  if (pass === "1234") {
    console.log("Login successful");
  }
}

let num = 15;

if (num > 10) {
  if (num < 20) {
    console.log("Number is between 10 and 20");
  }
}

let marks = 85;

if (marks >= 35) {
  if (marks >= 75) {
    console.log("Passed with distinction");
  }
}

let day = "Monday";
let hour = 10;

if (day === "Monday") {
  if (hour < 18) {
    console.log("Office open");
  }
}

let available = true;
let price = 500;

if (available) {
  if (price <= 1000) {
    console.log("Can buy item");
  }
}
