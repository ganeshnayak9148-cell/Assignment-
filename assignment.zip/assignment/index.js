// declare using let
let y
//assign value
y = 12
console.log(y)
//re  declare
y = 13
console.log(y)

//arathemitic values 
let a = 30;
let b = 20;
let c = a+b;
console.log(c)

let d = 30;
let e = 20;
let f = d-e;
console.log(f)

let g = 30;
let h = 20;
let p = g/h;
console.log(p)

let j = 3;
let k = 2;
let l = j*k;
console.log(l)

let m = 3;
let n = 2;
let o = m**n;
console.log(o)

let aa = 15;
let bb = 20;

console.log(aa == bb);   
console.log(aa === bb);  
console.log(aa > 5);    
console.log(aa <= 10);  
console.log(aa!== bb);

let z = "12ABC";
console.log(z==z)
console.log(z===z)
console.log(typeof(z))

let gg ="5"+2 +3
let hh =2+3+"6"
console.log(gg)
console.log(hh)
console.log(typeof(gg))
console.log(typeof(hh))

let info;
console.log(info)
console.log(typeof(info))

let text1 = "hi"
let text2 = "hello"
console.log(text1+text2)
console.log(text1+" "+text2)

let inf="good morning"
inf="good morning have a great day"
console.log(inf)
console.log(typeof(inf))

let age = 18;
let text = "You can Not drive!";

if (age >= 18) {
  text = "You can drive!";
}
console.log(text)

let age1 = 11;
let tex = "You can Not drive!";

if (age >= 18) {
  text = "You can drive!";
}
console.log(tex)

let ages = 18;
let country = "USA";
let texts = "You can Not drive!";

if (country =="USA") {
    if (ages >= 18) {
        text = "you can drive"
    }
}
console.log(texts)

